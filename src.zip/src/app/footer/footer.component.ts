import { Component, OnInit } from '@angular/core';
import {kaur3978} from '../kaur3978';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  
  currstudent : kaur3978 = {
    kid : 991494199 ,
    kname :' Ramandeep Kaur' ,
    klogin : 'kaur3978' ,
    kcampus : 'sheridan',
    kassign : 'assignment 4'
  };

  constructor() { }

  ngOnInit() {
  }

}
