import { Component, OnInit } from '@angular/core';
import{kaur3978} from '../kaur3978';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  currstudent : kaur3978 = {
    kid : 991494199 ,
    kname :' Ramandeep Kaur' ,
    klogin : 'kaur3978' ,
    kcampus : 'sheridan',
    kassign : 'assignment 4'
  };

  constructor() { }

  ngOnInit() {
  }

}
