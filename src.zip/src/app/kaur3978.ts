export class kaur3978 {
    kid : number;
    kname : string;
    klogin : string;
    kcampus : string;
    kassign : string;

}